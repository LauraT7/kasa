import React from 'react'
import './Apartment.css'
import {Link} from "react-router-dom"

// Définition du composant Apartment
// Ce composant représente la structure visuelle d'un appartement dans une liste d'appartements.
function Apartment(props) {
  return (
    // Conteneur principal de l'appartement avec une classe CSS 'apartment'
    <div className='apartment'>
      {/* Image de l'appartement avec l'URL spécifiée dans les propriétés 'imageUrl' */}
      <img src={props.imageUrl} alt=""/>
      {/* Lien vers la page détaillée de l'appartement */}
      {/* Le lien utilise le composant 'Link' de React Router pour gérer la navigation */}
      {/* L'ID de l'appartement est passé dans l'objet 'state' pour être récupéré dans la page détaillée */}
      <Link to="/flat" state={{
        apartmentId: props.id
      }}>
        {/* Titre de l'appartement */}
        <h3>{props.title}</h3>
      </Link>
    </div>
  )
}

// Export du composant Apartment pour qu'il puisse être utilisé ailleurs dans l'application
export default Apartment
