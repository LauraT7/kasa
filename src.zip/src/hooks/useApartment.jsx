import { useEffect, useState } from "react"
import { useLocation } from "react-router-dom"

// Définition du hook personnalisé useApartment
export function useApartment() {
  // Déclaration d'un état local 'flat' et de la fonction 'setFlat' pour le mettre à jour
  const [flat, setFlat] = useState(null)
  
  // Obtention de l'objet 'location' à l'aide du hook 'useLocation' de React Router
  const location = useLocation()

  // Effet secondaire déclenché lorsque le composant monte
  useEffect(() => {
    // Variable pour indiquer si le composant est monté ou pas
    let isMounted = true
    
    // Création d'un contrôleur d'abandon pour annuler la requête en cas de démontage du composant
    const abortController = new AbortController()
  
    // Effectuer une requête GET pour récupérer les données des appartements depuis un fichier JSON
    fetch("/apartment.json", { signal: abortController.signal })
      .then((res) => res.json())
      .then((flats) => {
        // Vérification si le composant est toujours monté avant de mettre à jour l'état
        if (isMounted) {
          // Trouver l'appartement correspondant à l'ID passé via l'objet 'location'
          const flat = flats.find((flat) => flat.id === location.state.apartmentId)
          // Mettre à jour l'état 'flat' avec les données de l'appartement trouvé
          setFlat(flat)
        }
      })
      .catch((error) => {
        // Gérer les erreurs, en s'assurant de ne pas traiter les erreurs d'abandon
        if (error.name !== 'AbortError') {
          console.error(error)
        }
      })
  
    // Fonction de nettoyage pour annuler la requête en cas de démontage du composant
    return () => {
      abortController.abort() // Annuler la requête
      isMounted = false // Mettre à false pour indiquer que le composant est démonté
    }
  }, []) // Ce hook d'effet ne s'exécute qu'une seule fois au montage du composant
  
  // Renvoie l'état 'flat', qui contient les données de l'appartement sélectionné
  return flat
}
