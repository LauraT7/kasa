import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter, Routes, Route } from "react-router-dom";
import App from './App';
import About from './pages/About';
import Flat from './pages/Flat';
import Error from './pages/Error';
import './index.css';

// Rendu de l'arborescence de composants React dans le DOM
ReactDOM.createRoot(document.getElementById('root')).render(
  // Début du mode strict de React
  <React.StrictMode>
    {/* Utilisation du routeur HashRouter pour la gestion des routes */}
    <HashRouter>
      {/* Conteneur pour les routes de l'application */}
      <Routes>
        {/* Route pour le chemin d'URL '/' (racine de l'application) */}
        <Route path="/" element={<App />} />
        {/* Route pour le chemin d'URL '/flat' */}
        <Route path="/flat" element={<Flat />} />
        {/* Route pour le chemin d'URL '/about' */}
        <Route path="/about" element={<About />} />
        {/* Route de secours pour tous les autres chemins d'URL */}
        <Route path="*" element={<Error />} />
      </Routes>
    </HashRouter>
  </React.StrictMode>
)