import { Link } from 'react-router-dom';

import React from 'react'
import Navbar from '../assets/components/Navbar'
import Footer from '../assets/components/Footer'
import './Error.css'

// Définition du composant Error, qui représente la page d'erreur 404
function Error() {
  // Renvoie une structure de composants JSX
  return (
    // Conteneur principal de la page d'erreur
    <div>
      {/* Composant de la barre de navigation */}
      <Navbar />
      
      {/* Conteneur de la page d'erreur avec une classe CSS spécifique */}
      <div className="error-page">
        {/* Titre principal indiquant le code d'erreur 404 */}
        <h1>404</h1>
        
        {/* Message indiquant que la page demandée n'existe pas */}
        <h2>Oops! La page que vous demandez n'existe pas</h2>
        
        {/* Lien permettant de retourner à la page d'accueil */}
        {/* Le lien est créé à l'aide du composant Link de React Router */}
        <Link to="/">Retourner sur la page d'accueil</Link>
      </div>
      
      {/* Composant du pied de page */}
      <Footer />
    </div>
  );
}


export default Error