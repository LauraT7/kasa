import React, { useEffect, useState } from "react"
import Navbar from '../assets/components/Navbar'
import Footer from '../assets/components/Footer'
import { useLocation } from "react-router-dom"
import { ImageBanner } from "../assets/components/ImageBanner"
import { useApartment } from "../hooks/useApartment"
import { ApartmentHeader } from "../assets/components/ApartmentHeader"
import Description from "../assets/components/Description"
 
function Flat() {
  const location = useLocation()
  // console.log("location", location)
  const flat = useApartment()
  if (flat == null) return <div>Loading...</div>
  // useEffect(fetchApartmentData, [])
  // function fetchApartmentData() {
  //   fetch("./apartment.json")

  // }

// Renvoie une structure de composants JSX
return (
  // Conteneur principal avec plusieurs composants enfants
  <div>
    {/* Composant de la barre de navigation */}
    <Navbar />
    {/* Composant de la bannière d'image avec les images des appartements */}
      {/* Les images de l'appartement sont passées en tant que propriété 'pictures' au composant ImageBanner */}
      <ImageBanner pictures={flat.pictures} />

      {/* Composant de l'en-tête de l'appartement */}
      {/* Les détails de l'appartement sont passés en tant que propriété 'flat' au composant ApartmentHeader */}
      <ApartmentHeader flat={flat} />
      
      {/* Composant de la description de l'appartement */}
      {/* La description de l'appartement est passée en tant que propriété 'content' au composant Description */}
      <Description title="Description" content={flat.description} />
      
      {/* Composant des équipements de l'appartement */}
      {/* La liste des équipements de l'appartement est mappée et passée en tant que propriété 'content' au composant Description */}
      {/* Chaque élément de la liste est rendu à l'intérieur d'une balise <li> */}
      <Description title="Equipements"
        content={flat.equipments.map((eq, i) => (
          <li key={i}>{eq}</li>
        ))}/>
    {/* Composant du pied de page */}
    <Footer />
  </div>
)}


export default Flat